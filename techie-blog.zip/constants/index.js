export const databaseUrl = process.env.MONGODB_URI || "";
